import java.util.ArrayList;

/**
 * Created by ASUS PC on 9/26/2016.
 */
public class GottaCatchemAll extends Problem {
	
    public GottaCatchemAll(String [] operators, PokemonState initialState, int pathCost , PokemonState GoalState ){
        super(operators, initialState, pathCost,  GoalState);
    }
 
    }
   

