
public enum Operators {
Forward, RotateRight, RotateLeft;


}
