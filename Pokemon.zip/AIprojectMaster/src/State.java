
public abstract class State {

	public State() {
		super();
		
	}
	
}
